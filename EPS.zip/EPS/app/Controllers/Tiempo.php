<?php

namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\m_tiempo;

class Tiempo extends Controller
{
    public function index()
    {
        $pac = new m_tiempo();
        $datos['registro_tiempo']=$pac->findAll();
        return view('tiempo',$datos);
    }

    
    // Función para obtener el nombre del conductor por su ID
    // function obtenerNombreConductor($idConductor)
    // {
    //     Realiza la consulta a la tabla conductores para obtener el nombre del conductor
    //     $db = \Config\Database::connect(); // Conexión a la base de datos (puede variar dependiendo de tu configuración)
    //     $query = $db->query("SELECT nombre FROM conductores WHERE idConductor = $idConductor");
    //     $result = $query->getRow();

    //     if ($result) {
    //         return $result->nombre;
    //     }

    //     return "Nombre del Conductor no encontrado";
    // }

    // Función para obtener la placa del vehículo por su ID
    // function obtenerPlacaVehiculo($idVehiculo)
    // {
    //     Realiza la consulta a la tabla vehiculos para obtener la placa del vehículo
    //     $db = \Config\Database::connect(); // Conexión a la base de datos (puede variar dependiendo de tu configuración)
    //     $query = $db->query("SELECT placa FROM vehiculos WHERE idVehiculo = $idVehiculo");
    //     $result = $query->getRow();

    //     if ($result) {
    //         return $result->placa;
    //     }

    //     return "Placa del Vehículo no encontrada";
    // }

    public function calcularPrecio()
    {
            // Calcular el tiempo transcurrido en minutos
            $fechaHoraIngreso = strtotime($tiempo['fecha_hora_ingreso']);
            $fechaHoraSalida = strtotime($tiempo['fecha_hora_salida']);
            $tiempoTranscurrido = floor(($fechaHoraSalida - $fechaHoraIngreso) / 60);

            // Calcular el precio según la tarifa
            $precioPorMinuto = 300; // Precio por minuto
            $precioPagar = $tiempoTranscurrido * $precioPorMinuto;

            // Actualizar el valor a pagar en el registro de tiempo
            $registro['valor_pagar'] = $precioPagar;
            $registroTiempoModel->save($registro);

            // Redirigir al usuario a una página de éxito o mostrar el resultado de alguna manera
            return redirect()->to(base_url('tiempo'));
       

        // Almacenar el resultado en una variable de sesión
        session()->setFlashdata('precioCalculado', $precioPagar);

        // Redirigir al usuario a una página de éxito o mostrar el resultado de alguna manera
        return redirect()->to(base_url('tiempo'));

    }
}
