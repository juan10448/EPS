<?php 
namespace App\Models;

use CodeIgniter\Model;

class M_conductor extends Model{
    protected $table      = 'conductores';
    // Uncomment below if you want add primary key
     protected $primaryKey = 'idConductor';

    protected $allowedFields = ['cedula','nombre','direccion','telefono'];
}