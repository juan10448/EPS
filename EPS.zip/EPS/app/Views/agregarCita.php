<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro vehiculo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
</head>
<style>
   body {
      font-family: 'Times New Roman', Times, serif;
      background-color: #e6e6e6;
      margin: 0;
      padding: 0;
   }

   h1 {
      color: #800000;
      text-align: center;
      margin-top: 30px;
   }

   ul {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      margin-top: 30px;
      border-top: 2px solid #800000;
      border-bottom: 2px solid #800000;
      padding: 10px 0;
   }

   li {
      margin-bottom: 10px;
   }

   a {
      text-decoration: none;
      color: #800000;
      font-weight: bold;
      transition: color 0.3s ease;
   }

   a:hover {
      color: #ff0000;
   }

   table {
      border: 1px solid #800000;
      width: 100%;
   }

   th,
   td {
      text-align: center;
      padding: 8px;
      border: 1px solid #800000;
   }

   tr:nth-child(even) {
      background-color: #f2f2f2;
   }

   th {
      background-color: #800000;
      color: white;
   }

   tr:hover {
      background-color: grey;
   }
</style>
<body>
    <div class="container"><br> <br>
        <div class="container-fluid">
            <h1>Agregar Vehiculo</h1>
            <form action="insertarV" method="POST">
                <div class="form-group">
                    <input type="number" hidden name="idVehiculo">
                    <label for="exampleInputEmail1">Placa:</label>
                    <input type="text" class="form-control" id="placa" name="placa"  required aria-describedby="emailHelp">
                </div>

                <div class="form-group">
                    <label for="exampleInputEmail1">Marca:</label>
                    <input type="text" class="form-control" id="marca" name="marca"  required aria-describedby="emailHelp">
                </div>

                <div class="form-group">
                    <label for="exampleInputEmail1">Modelo:</label>
                    <input type="text" class="form-control" id="modelo" name="modelo" required aria-describedby="emailHelp">
                </div>

                <div class="form-group">
                    <label for="exampleInputEmail1">Color:</label>
                    <input type="text" class="form-control" id="color" name="color" required aria-describedby="emailHelp">
                </div>

                <button type="submit" class="btn btn-primary">Registrar</button>
                <button type="button" class="btn btn-danger" onclick="window.location.href='<?php echo base_url('vehiculopg'); ?>'">Volver</button>

            </form>
        </div>
    </div>

</body>

</html>