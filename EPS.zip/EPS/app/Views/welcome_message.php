<!DOCTYPE html>
<html lang="en">

<head>
	<title>EPS</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/style.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
</head>

<body >
<style>
   body {
      font-family: 'Times New Roman', Times, serif;
      background-color: #e6e6e6;
      margin: 0;
      padding: 0;
   }

   h1 {
      color: #800000;
      text-align: center;
      margin-top: 30px;
   }

   ul {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      margin-top: 30px;
      border-top: 2px solid #800000;
      border-bottom: 2px solid #800000;
      padding: 10px 0;
   }

   li {
      margin-bottom: 10px;
   }

   a {
      text-decoration: none;
      color: #800000;
      font-weight: bold;
      transition: color 0.3s ease;
   }

   a:hover {
      color: #ff0000;
   }

   table {
      border: 1px solid #800000;
      width: 100%;
   }

   th,
   td {
      text-align: center;
      padding: 8px;
      border: 1px solid #800000;
   }

   tr:nth-child(even) {
      background-color: #f2f2f2;
   }

   th {
      background-color: #800000;
      color: white;
   }

   tr:hover {
      background-color: grey;
   }
</style>

<h1>EPS</h1>
<ul>
  <li><a href="<?php echo base_url('paciente'); ?>">PACIENTE</a></li>
  <li><a href="<?php echo base_url('Citas'); ?>">CITAS</a></li>
</ul>
<br><br>
<style>
  table {
    width: 300px;
    border-collapse: collapse;
    border: none;
    margin: 0 auto;
    font-family: Arial, sans-serif;
  }

  th, td {
    padding: 8px;
    text-align: left;
  }

  th {
    background-color: #f2f2f2;
  }

  tbody tr:nth-child(even) {
    background-color: #f9f9f9;
  }

  tbody td:first-child {
    font-weight: bold;
  }
</style>

<table>
 
  <tbody>
    <tr>
      <td>
      LÍNEAS DE ATENCIÓN
      Régimen Contributivo
      Marca desde teléfono fijo a la línea gratuita nacional al
      01 8000 954400
      En Bogotá, desde fijo o celular, al
      (601) 307 7022
      Régimen Subsidiado
      Marca desde teléfono fijo a la línea gratuita nacional al
      01 8000 952000
      En Bogotá, desde fijo o celular, al
      (601) 307 70 51
      Línea de atención COVID-19 y Viruela Símica:
      01 8000 930100
      Desde celular marca
      #961
      (únicamente para operadores Claro, Tigo y Movistar) Desde teléfono fijo, o cualquier operador celular, a la línea gratuita:
      01 8000 930100
      .
      Oficinas administrativas
      Dirección Nacional
      Carrera 85K No. 46A-66
      Bogotá D.C., Colombia
      Teléfono administrativo
      (60)1 419 3000
      Conoce las Sedes administrativas
    </td>
      
  </tbody>
</table>
	<!-- <div class="footer">
		<p> 2023 eps.</p>
    </div> -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>
</body>

</html>